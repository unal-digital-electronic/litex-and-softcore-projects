# Programación de ColorLight 5A-75E con adaptador USB FT232

![Introducción](./img/intro.png)

El adaptador USB-FT232 es usado generalmente como adapatdor USB a UART con niveles
de tensión de 5V o 3.3V. En éste ejemplo se mostrará como usa éste adapatdor para
programar la FPGA usando el protocolo JTAG.

## Requerimientos

* Adaptador USB FT232
* Cable USB
* ColorLight 5A 75E
* Archivos fuentes de  [openocd](https://sourceforge.net/projects/openocd/)
* Archivo de configuración de FPGA para hacer el blink en la FPGA.
* Script de programación program.sh
* Archivo de configuración

**Nota**: En el siguiente [archivo .zip]()

## Pasos

### 1. Compilación de openocd

```bash
git clone https://git.code.sf.net/p/openocd/code openocd-code
cd openocd-code
./bootstrap
./configure --enable-ft232r
make
sudo make install
```


### 2. udev rules y permisos de usuario

#### Reglas udev
// TODO

#### Permisos de usuario
// TODO

### 3. Configuración de FPGA Blink

Para hacer el blink de prueba, ejecute el siguiente comando

```bash
sh program.sh blink.svf
```

Inmediatamente después de la ejecución el LED de usuario iniciará
el parpadeo.


### Observaciones

El principal uso del ft232 es la comunicación UART, pero cuando
es usado por el openocd para configurar la FPGA, el sistema operativo
depués de ésta acción ya no lo detecta como un puerto serial `/dev/ttyUSBx`; a continuación
planteo un par de consejos:

1. Cuando desee configurar la FPGA por éste medio, desconecte los pines
correspondientes a RX y TX del adaptador UART antes de proceder.

2. Si ha configurado la FPGA haciendo uso del adaptador FT232 y seguido,
quiere con éste probar una comunicación UART, desconecte el
adaptador del puerto USB de su equipo y seguido de ello vuelva a conectar,
al revisar por ejemplo con el comando `ls -l /dev/ttyUSB*` el adaptador
volverá a tener un archivo que lo represente como un dispositivo serial-terminal.

