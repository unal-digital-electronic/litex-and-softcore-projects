#!/usr/bin/env python3
import os
os.system("openFPGALoader -c colorlight-ft232rl ./build/gateware/top.bit")
